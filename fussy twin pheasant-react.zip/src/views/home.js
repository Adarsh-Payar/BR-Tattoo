import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'

import Navbar8 from '../components/navbar8'
import Hero17 from '../components/hero17'
import Features24 from '../components/features24'
import CTA26 from '../components/cta26'
import Features25 from '../components/features25'
import Pricing14 from '../components/pricing14'
import Steps2 from '../components/steps2'
import Testimonial17 from '../components/testimonial17'
import Contact10 from '../components/contact10'
import Footer4 from '../components/footer4'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Fussy Twin Pheasant</title>
        <meta property="og:title" content="Fussy Twin Pheasant" />
      </Helmet>
      <Navbar8
        page4Description={
          <Fragment>
            <span className="home-text100">Page Four Description</span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text101">Main Action</span>
          </Fragment>
        }
        link2={
          <Fragment>
            <span className="home-text102">Tattoo Designs</span>
          </Fragment>
        }
        page1={
          <Fragment>
            <span className="home-text103">Page One</span>
          </Fragment>
        }
        link1={
          <Fragment>
            <span className="home-text104">Home</span>
          </Fragment>
        }
        page4={
          <Fragment>
            <span className="home-text105">Page Four</span>
          </Fragment>
        }
        page2={
          <Fragment>
            <span className="home-text106">Page Two</span>
          </Fragment>
        }
        link4={
          <Fragment>
            <span className="home-text107">Appointments</span>
          </Fragment>
        }
        page1Description={
          <Fragment>
            <span className="home-text108">Page One Description</span>
          </Fragment>
        }
        page2Description={
          <Fragment>
            <span className="home-text109">Page Two Description</span>
          </Fragment>
        }
        link3={
          <Fragment>
            <span className="home-text110">Artist Portfolios</span>
          </Fragment>
        }
        page3={
          <Fragment>
            <span className="home-text111">Page Three</span>
          </Fragment>
        }
        page3Description={
          <Fragment>
            <span className="home-text112">Page Three Description</span>
          </Fragment>
        }
        action2={
          <Fragment>
            <span className="home-text113">Secondary Action</span>
          </Fragment>
        }
      ></Navbar8>
      <Hero17
        action2={
          <Fragment>
            <span className="home-text114">Browse Designs</span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text115">Book Now</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text116">Welcome to BK Tattoo!</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text117">
              Experience bespoke tattoos with precision and artistry. Explore
              trending designs like Shiva and Mandala, and enjoy virtual
              consultations.
            </span>
          </Fragment>
        }
      ></Hero17>
      <Features24
        feature3Description={
          <Fragment>
            <span className="home-text118">
              Browse through a wide range of artist portfolios to find the
              perfect match for your tattoo vision.
            </span>
          </Fragment>
        }
        feature3Title={
          <Fragment>
            <span className="home-text119">Artist Portfolios</span>
          </Fragment>
        }
        feature2Description={
          <Fragment>
            <span className="home-text120">
              Access aftercare tips to ensure your tattoo heals beautifully and
              maintains its vibrancy.
            </span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="home-text121">Trending Designs</span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="home-text122">
              Explore popular tattoo designs like Shiva and Mandala that are
              trending in the tattoo world.
            </span>
          </Fragment>
        }
        feature2Title={
          <Fragment>
            <span className="home-text123">Aftercare Tips</span>
          </Fragment>
        }
      ></Features24>
      <CTA26
        heading1={
          <Fragment>
            <span className="home-text124">Ready to get inked?</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text125">
              Browse our trending designs or consult with our artists for a
              custom tattoo.
            </span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text126">Book an Appointment</span>
          </Fragment>
        }
      ></CTA26>
      <Features25
        feature3Description={
          <Fragment>
            <span className="home-text127">
              Browse through our artists&apos; portfolios to find the perfect
              match for your tattoo.
            </span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="home-text128">
              Explore popular tattoo designs like Shiva and Mandala.
            </span>
          </Fragment>
        }
        feature2Title={
          <Fragment>
            <span className="home-text129">Virtual Consultations</span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="home-text130">Trending Designs</span>
          </Fragment>
        }
        feature2Description={
          <Fragment>
            <span className="home-text131">
              Get virtual consultations with our talented artists.
            </span>
          </Fragment>
        }
        feature3Title={
          <Fragment>
            <span className="home-text132">Artist Portfolios</span>
          </Fragment>
        }
      ></Features25>
      <Pricing14
        plan3Price={
          <Fragment>
            <span className="home-text133">$49/mo</span>
          </Fragment>
        }
        plan3Action={
          <Fragment>
            <span className="home-text134">Get started</span>
          </Fragment>
        }
        plan11={
          <Fragment>
            <span className="home-text135">Basic plan</span>
          </Fragment>
        }
        plan1Action={
          <Fragment>
            <span className="home-text136">Get started</span>
          </Fragment>
        }
        plan31={
          <Fragment>
            <span className="home-text137">Enterprise plan</span>
          </Fragment>
        }
        plan3Feature41={
          <Fragment>
            <span className="home-text138">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature2={
          <Fragment>
            <span className="home-text139">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature11={
          <Fragment>
            <span className="home-text140">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature51={
          <Fragment>
            <span className="home-text141">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature41={
          <Fragment>
            <span className="home-text142">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature2={
          <Fragment>
            <span className="home-text143">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature21={
          <Fragment>
            <span className="home-text144">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature4={
          <Fragment>
            <span className="home-text145">Feature text goes here</span>
          </Fragment>
        }
        plan2Yearly={
          <Fragment>
            <span className="home-text146">or $299 yearly</span>
          </Fragment>
        }
        plan1Action1={
          <Fragment>
            <span className="home-text147">Get started</span>
          </Fragment>
        }
        plan2Action={
          <Fragment>
            <span className="home-text148">Get started</span>
          </Fragment>
        }
        plan3Feature1={
          <Fragment>
            <span className="home-text149">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature3={
          <Fragment>
            <span className="home-text150">Feature text goes here</span>
          </Fragment>
        }
        plan1Price1={
          <Fragment>
            <span className="home-text151">$200/yr</span>
          </Fragment>
        }
        plan2={
          <Fragment>
            <span className="home-text152">Business plan</span>
          </Fragment>
        }
        plan2Feature21={
          <Fragment>
            <span className="home-text153">Feature text goes here</span>
          </Fragment>
        }
        plan2Action1={
          <Fragment>
            <span className="home-text154">Get started</span>
          </Fragment>
        }
        plan3Feature2={
          <Fragment>
            <span className="home-text155">Feature text goes here</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text156">
              Choose the perfect plan for you
            </span>
          </Fragment>
        }
        plan2Feature1={
          <Fragment>
            <span className="home-text157">Feature text goes here</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text158">Pricing plan</span>
          </Fragment>
        }
        plan3Feature31={
          <Fragment>
            <span className="home-text159">Feature text goes here</span>
          </Fragment>
        }
        plan1={
          <Fragment>
            <span className="home-text160">Basic plan</span>
          </Fragment>
        }
        plan21={
          <Fragment>
            <span className="home-text161">Business plan</span>
          </Fragment>
        }
        plan1Feature11={
          <Fragment>
            <span className="home-text162">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature21={
          <Fragment>
            <span className="home-text163">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature5={
          <Fragment>
            <span className="home-text164">Feature text goes here</span>
          </Fragment>
        }
        plan2Yearly1={
          <Fragment>
            <span className="home-text165">or $29 monthly</span>
          </Fragment>
        }
        plan2Price={
          <Fragment>
            <span className="home-text166">$29/mo</span>
          </Fragment>
        }
        plan3Yearly1={
          <Fragment>
            <span className="home-text167">or $49 monthly</span>
          </Fragment>
        }
        plan2Feature31={
          <Fragment>
            <span className="home-text168">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature11={
          <Fragment>
            <span className="home-text169">Feature text goes here</span>
          </Fragment>
        }
        plan1Yearly1={
          <Fragment>
            <span className="home-text170">or $20 monthly</span>
          </Fragment>
        }
        plan2Price1={
          <Fragment>
            <span className="home-text171">$299/yr</span>
          </Fragment>
        }
        plan3Yearly={
          <Fragment>
            <span className="home-text172">or $499 yearly</span>
          </Fragment>
        }
        plan3Feature4={
          <Fragment>
            <span className="home-text173">Feature text goes here</span>
          </Fragment>
        }
        plan3Price1={
          <Fragment>
            <span className="home-text174">$499/yr</span>
          </Fragment>
        }
        plan1Feature31={
          <Fragment>
            <span className="home-text175">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature3={
          <Fragment>
            <span className="home-text176">Feature text goes here</span>
          </Fragment>
        }
        plan1Yearly={
          <Fragment>
            <span className="home-text177">or $200 yearly</span>
          </Fragment>
        }
        plan1Feature1={
          <Fragment>
            <span className="home-text178">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature3={
          <Fragment>
            <span className="home-text179">Feature text goes here</span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="home-text180">
              <span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
          </Fragment>
        }
        plan3Action1={
          <Fragment>
            <span className="home-text183">Get started</span>
          </Fragment>
        }
        plan1Price={
          <Fragment>
            <span className="home-text184">$20/mo</span>
          </Fragment>
        }
        plan3={
          <Fragment>
            <span className="home-text185">Enterprise plan</span>
          </Fragment>
        }
      ></Pricing14>
      <Steps2
        step1Description={
          <Fragment>
            <span className="home-text186">
              Explore popular tattoo designs like Shiva and Mandala to find
              inspiration for your next tattoo.
            </span>
          </Fragment>
        }
        step3Description={
          <Fragment>
            <span className="home-text187">
              Get personalized advice and discuss your tattoo ideas with our
              artists through virtual consultations.
            </span>
          </Fragment>
        }
        step2Title={
          <Fragment>
            <span className="home-text188">Book Appointments</span>
          </Fragment>
        }
        step2Description={
          <Fragment>
            <span className="home-text189">
              Easily schedule your tattoo sessions with our talented artists
              through the app for convenience.
            </span>
          </Fragment>
        }
        step1Title={
          <Fragment>
            <span className="home-text190">Browse Trending Designs</span>
          </Fragment>
        }
        step3Title={
          <Fragment>
            <span className="home-text191">Virtual Consultations</span>
          </Fragment>
        }
        step4Description={
          <Fragment>
            <span className="home-text192">
              Learn how to properly care for your new tattoo with our aftercare
              tips to ensure vibrant and long-lasting results.
            </span>
          </Fragment>
        }
        step4Title={
          <Fragment>
            <span className="home-text193">Access Aftercare Tips</span>
          </Fragment>
        }
      ></Steps2>
      <Testimonial17
        author2Position={
          <Fragment>
            <span className="home-text194">Software Engineer</span>
          </Fragment>
        }
        author1Position={
          <Fragment>
            <span className="home-text195">Graphic Designer</span>
          </Fragment>
        }
        author1Name={
          <Fragment>
            <span className="home-text196">Riya Patel</span>
          </Fragment>
        }
        author3Name={
          <Fragment>
            <span className="home-text197">Priya Sharma</span>
          </Fragment>
        }
        review2={
          <Fragment>
            <span className="home-text198">
              Amazing experience! The attention to detail and creativity of the
              artists at BK Tattoo is unmatched. Highly recommended!
            </span>
          </Fragment>
        }
        author2Name={
          <Fragment>
            <span className="home-text199">Amit Singh</span>
          </Fragment>
        }
        author4Position={
          <Fragment>
            <span className="home-text200">Entrepreneur</span>
          </Fragment>
        }
        author4Name={
          <Fragment>
            <span className="home-text201">Rahul Mehta</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text202">
              I got my first tattoo from BK Tattoo, and I couldn&apos;t be
              happier with the result. The artist understood exactly what I
              wanted and brought it to life beautifully.
            </span>
          </Fragment>
        }
        author3Position={
          <Fragment>
            <span className="home-text203">Marketing Manager</span>
          </Fragment>
        }
        review1={
          <Fragment>
            <span className="home-text204">5 stars</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text205">Client Testimonials</span>
          </Fragment>
        }
        review3={
          <Fragment>
            <span className="home-text206">
              I had a fantastic consultation session with the artist before
              getting my tattoo. The whole process was smooth, and the final
              result exceeded my expectations.
            </span>
          </Fragment>
        }
        review4={
          <Fragment>
            <span className="home-text207">
              BK Tattoo is my go-to place for unique and personalized tattoos.
              The artists here are truly talented and professional.
            </span>
          </Fragment>
        }
      ></Testimonial17>
      <Contact10
        content1={
          <Fragment>
            <span className="home-text208">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse varius enim in ero.
            </span>
          </Fragment>
        }
        location1Description={
          <Fragment>
            <span className="home-text209">
              Visit us at our studio located at 123 Main Street, City, Country.
            </span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text210">Contact Us</span>
          </Fragment>
        }
        location2Description={
          <Fragment>
            <span className="home-text211">
              Schedule a virtual consultation with our artists from the comfort
              of your home.
            </span>
          </Fragment>
        }
        location1={
          <Fragment>
            <span className="home-text212">BK Tattoo Studio</span>
          </Fragment>
        }
        location2={
          <Fragment>
            <span className="home-text213">Virtual Consultations</span>
          </Fragment>
        }
      ></Contact10>
      <Footer4
        link5={
          <Fragment>
            <span className="home-text214">Contact Us</span>
          </Fragment>
        }
        link3={
          <Fragment>
            <span className="home-text215">Aftercare Tips</span>
          </Fragment>
        }
        link1={
          <Fragment>
            <span className="home-text216">Book Appointment</span>
          </Fragment>
        }
        termsLink={
          <Fragment>
            <span className="home-text217">Terms and Conditions</span>
          </Fragment>
        }
        link2={
          <Fragment>
            <span className="home-text218">Browse Artists</span>
          </Fragment>
        }
        link4={
          <Fragment>
            <span className="home-text219">Rewards Program</span>
          </Fragment>
        }
        cookiesLink={
          <Fragment>
            <span className="home-text220">Cookie Policy</span>
          </Fragment>
        }
        privacyLink={
          <Fragment>
            <span className="home-text221">Privacy Policy</span>
          </Fragment>
        }
      ></Footer4>
    </div>
  )
}

export default Home
